import radar from './radar.png'

const config = {
    "config": {
        "origin": {
            "x": 927.3988878244819,
            "y": 343.8221009185496
        },
        "pxPerUX": 0.1923720959212443,
        "pxPerUY": -0.19427507725530338
    },
    "file":radar
}

export default config;