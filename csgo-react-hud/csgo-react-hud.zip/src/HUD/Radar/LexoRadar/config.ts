const config = {
    playerSize: 40,
}

export default config;